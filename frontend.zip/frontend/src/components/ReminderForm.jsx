import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { createReminder, updateReminder, getReminderById } from '../services/reminder';

const ReminderForm = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const isEdit = Boolean(id);

  const [form, setForm] = useState({
    title: '',
    description: '',
    due_date: '',
  });

  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // Check if user is logged in
    const token = localStorage.getItem('token');
    if (!token) {
      navigate('/login');
      return;
    }

    if (isEdit) {
      loadReminder();
    }
  }, [id, isEdit, navigate]);

  const loadReminder = async () => {
    try {
      const data = await getReminderById(id);
      setForm({
        title: data.title,
        description: data.description,
        due_date: new Date(data.due_date).toISOString().slice(0, 16),
      });
    } catch (err) {
      console.error('Failed to load reminder:', err);
      if (err.message.includes('log in')) {
        navigate('/login');
      } else {
        setError('Failed to load reminder. Please try again.');
      }
    }
  };

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      // Check if user is logged in
      const token = localStorage.getItem('token');
      if (!token) {
        navigate('/login');
        return;
      }

      // Format the date to ISO string and ensure it's a valid date
      const dueDate = new Date(form.due_date);
      if (isNaN(dueDate.getTime())) {
        throw new Error('Invalid date format');
      }

      const reminderData = {
        title: form.title,
        description: form.description || null,
        due_date: dueDate.toISOString()
      };

      console.log('Submitting reminder data:', reminderData);
      console.log('Auth token:', token);

      if (isEdit) {
        await updateReminder(id, reminderData);
      } else {
        const response = await createReminder(reminderData);
        console.log('Reminder created successfully:', response);
      }
      navigate('/dashboard');
    } catch (err) {
      console.error('Failed to save reminder:', err);
      console.error('Error details:', err.response?.data);
      console.error('Error status:', err.response?.status);
      console.error('Error headers:', err.response?.headers);
      
      if (err.message.includes('log in')) {
        navigate('/login');
        return;
      }

      if (err.response?.status === 422) {
        const validationErrors = err.response.data.detail;
        if (Array.isArray(validationErrors)) {
          setError(validationErrors.map(err => err.msg).join(', '));
        } else {
          setError(validationErrors);
        }
      } else {
        setError(err.message || 'Failed to save reminder. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-4">
      <h2 className="text-2xl font-bold mb-6">
        {isEdit ? 'Edit Reminder' : 'New Reminder'}
      </h2>

      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="title" className="block text-sm font-medium text-gray-700">
            Title
          </label>
          <input
            type="text"
            id="title"
            name="title"
            value={form.title}
            onChange={handleChange}
            required
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          />
        </div>

        <div>
          <label htmlFor="description" className="block text-sm font-medium text-gray-700">
            Description
          </label>
          <textarea
            id="description"
            name="description"
            value={form.description}
            onChange={handleChange}
            rows="3"
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          />
        </div>

        <div>
          <label htmlFor="due_date" className="block text-sm font-medium text-gray-700">
            Due Date
          </label>
          <input
            type="datetime-local"
            id="due_date"
            name="due_date"
            value={form.due_date}
            onChange={handleChange}
            required
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          />
        </div>

        <div className="flex justify-end space-x-4">
          <button
            type="button"
            onClick={() => navigate('/dashboard')}
            className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={loading}
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"
          >
            {loading ? 'Saving...' : isEdit ? 'Update' : 'Create'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default ReminderForm; 