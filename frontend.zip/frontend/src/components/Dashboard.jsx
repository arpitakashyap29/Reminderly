import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getAllReminders, deleteReminder } from '../services/reminder';
import ReminderCard from './ReminderCard';

const Dashboard = () => {
  const [reminders, setReminders] = useState([]);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    loadReminders();
  }, []);

  const loadReminders = async () => {
    try {
      const data = await getAllReminders();
      setReminders(data);
    } catch (err) {
      console.error('Failed to load reminders:', err);
      setError('Failed to load reminders. Please try again.');
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this reminder?')) {
      try {
        await deleteReminder(id);
        await loadReminders();
      } catch (err) {
        console.error('Failed to delete reminder:', err);
        setError('Failed to delete reminder. Please try again.');
      }
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">My Reminders</h1>
        <button
          onClick={() => navigate('/reminders/new')}
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition"
        >
          New Reminder
        </button>
      </div>

      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {reminders.map((reminder) => (
          <ReminderCard
            key={reminder.id}
            reminder={reminder}
            onDelete={handleDelete}
          />
        ))}
      </div>

      {reminders.length === 0 && !error && (
        <div className="text-center text-gray-500 mt-8">
          No reminders yet. Create your first reminder!
        </div>
      )}
    </div>
  );
};

export default Dashboard; 