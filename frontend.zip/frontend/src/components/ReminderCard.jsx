import React from 'react';
import { useNavigate } from 'react-router-dom';

const ReminderCard = ({ reminder, onDelete }) => {
  const navigate = useNavigate();

  return (
    <div className="bg-white p-4 rounded shadow hover:shadow-md transition">
      <h3 className="text-xl font-semibold mb-2">{reminder.title}</h3>
      <p className="text-gray-600 mb-2">{reminder.description}</p>
      <p className="text-sm text-gray-500 mb-4">
        Due: {new Date(reminder.due_date).toLocaleString()}
      </p>
      <div className="flex gap-2">
        <button
          onClick={() => navigate(`/reminders/${reminder.id}/edit`)}
          className="bg-yellow-500 text-white px-3 py-1 rounded hover:bg-yellow-600 transition"
        >
          Edit
        </button>
        <button
          onClick={() => onDelete(reminder.id)}
          className="bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600 transition"
        >
          Delete
        </button>
      </div>
    </div>
  );
};

export default ReminderCard;
