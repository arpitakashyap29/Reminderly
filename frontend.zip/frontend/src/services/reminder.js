import api from './axios';

// Get auth token from localStorage
const getAuthHeader = () => {
  const token = localStorage.getItem('token');
  if (!token) {
    throw new Error('No authentication token found. Please log in.');
  }
  return { Authorization: `Bearer ${token}` };
};

// Get all reminders for the logged-in user
export const getAllReminders = async () => {
  try {
    console.log('Fetching reminders...');
    const token = localStorage.getItem('token');
    if (!token) {
      throw new Error('No authentication token found. Please log in.');
    }
    console.log('Using token:', token);

    const response = await api.get('/reminders/');
    console.log('Reminders fetched successfully:', response.data);
    return response.data;
  } catch (error) {
    console.error('Get reminders error:', error);
    if (error.code === 'ECONNABORTED') {
      throw new Error('Request timed out. Please check your connection.');
    }
    if (!error.response) {
      throw new Error('No response from server. Please check if the server is running.');
    }
    console.error('Error response:', error.response?.data);
    console.error('Error status:', error.response?.status);
    console.error('Error headers:', error.response?.headers);
    
    if (error.response?.status === 401) {
      throw new Error('Please log in to view reminders');
    }
    throw error;
  }
};

// Create a new reminder
export const createReminder = async (reminderData) => {
  try {
    console.log('Creating reminder with data:', reminderData);
    const token = localStorage.getItem('token');
    if (!token) {
      throw new Error('No authentication token found. Please log in.');
    }

    // Ensure the token is properly formatted
    const headers = {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    };

    console.log('Request headers:', headers);
    console.log('Request URL:', '/reminders/');
    console.log('Request data:', reminderData);

    const response = await api.post('/reminders/', reminderData, { headers });
    console.log('Reminder created successfully:', response.data);
    return response.data;
  } catch (error) {
    console.error('Create reminder error:', error);
    console.error('Error details:', error.response?.data);
    console.error('Error status:', error.response?.status);
    
    if (error.code === 'ECONNABORTED') {
      throw new Error('Request timed out. Please check your connection.');
    }
    if (!error.response) {
      throw new Error('No response from server. Please check if the server is running.');
    }
    if (error.response) {
      if (error.response.status === 401) {
        throw new Error('Please log in to create a reminder');
      } else if (error.response.status === 422) {
        const validationErrors = error.response.data.detail;
        if (Array.isArray(validationErrors)) {
          throw new Error(validationErrors.map(err => err.msg).join(', '));
        }
        throw new Error(validationErrors);
      }
    }
    throw error;
  }
};

// Update a reminder by ID
export const updateReminder = async (id, reminderData) => {
  try {
    const response = await api.put(`/reminders/${id}`, reminderData);
    return response.data;
  } catch (error) {
    console.error('Update reminder error:', error.response?.data || error.message);
    if (error.response?.status === 401) {
      throw new Error('Please log in to update this reminder');
    }
    throw error;
  }
};

// Get a reminder by ID
export const getReminderById = async (id) => {
  try {
    const response = await api.get(`/reminders/${id}`);
    return response.data;
  } catch (error) {
    console.error('Get reminder error:', error.response?.data || error.message);
    if (error.response?.status === 401) {
      throw new Error('Please log in to view this reminder');
    }
    throw error;
  }
};

// Delete a reminder by ID
export const deleteReminder = async (id) => {
  try {
    const response = await api.delete(`/reminders/${id}`);
    return response.data;
  } catch (error) {
    console.error('Delete reminder error:', error.response?.data || error.message);
    if (error.response?.status === 401) {
      throw new Error('Please log in to delete this reminder');
    }
    throw error;
  }
};
