import axios from "axios";

// Create an Axios instance with base URL of your backend
const instance = axios.create({
  baseURL: "http://127.0.0.1:8000", // Update this if deployed
  headers: {
    "Content-Type": "application/json",
  },
});

// Add JWT token from localStorage to every request, if available
instance.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem("token"); // JWT token from login
    if (token) {
      config.headers.Authorization = `Bearer ${token}`; // Add token to headers
    }
    return config;
  },
  (error) => Promise.reject(error)
);

export default instance;
