import api from './axios';

const API_BASE = "http://127.0.0.1:8000"; // Change this if deployed

// Register new user
export const registerUser = async (userData) => {
  try {
    console.log('Registering user:', userData);
    const response = await api.post('/auth/register', userData);
    console.log('Registration successful:', response.data);
    return response.data;
  } catch (error) {
    console.error('Registration error:', error);
    throw error;
  }
};

// Login user
export const loginUser = async (credentials) => {
  try {
    console.log('Logging in user:', credentials);
    const response = await api.post('/auth/login', credentials);
    console.log('Login successful:', response.data);
    return response.data;
  } catch (error) {
    console.error('Login error:', error);
    throw error;
  }
};

export const login = async (email, password) => {
  try {
    console.log('Attempting login for:', email);
    const response = await api.post('/auth/login', {
      email,
      password
    });
    console.log('Login successful:', response.data);
    return response.data;
  } catch (error) {
    console.error('Login error:', error);
    if (error.response) {
      console.error('Error response:', error.response.data);
      console.error('Error status:', error.response.status);
    }
    throw error;
  }
};

export const register = async (email, password) => {
  try {
    console.log('Attempting registration for:', email);
    const response = await api.post('/auth/register', {
      email,
      password
    });
    console.log('Registration successful:', response.data);
    return response.data;
  } catch (error) {
    console.error('Registration error:', error);
    if (error.response) {
      console.error('Error response:', error.response.data);
      console.error('Error status:', error.response.status);
    }
    throw error;
  }
};
