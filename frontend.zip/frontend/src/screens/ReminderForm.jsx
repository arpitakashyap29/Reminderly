import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { createReminder, updateReminder, getReminderById } from "../services/reminder";

const ReminderForm = () => {
  const navigate = useNavigate();
  const { id } = useParams(); // If editing, ID will be in the URL
  const isEdit = Boolean(id);

  const [form, setForm] = useState({
    title: "",
    description: "",
    remind_at: "",
  });

  const [error, setError] = useState("");

  useEffect(() => {
    if (isEdit) {
      (async () => {
        try {
          const data = await getReminderById(id);
          setForm({
            title: data.title,
            description: data.description,
            remind_at: data.remind_at.slice(0, 16), // format for input type="datetime-local"
          });
        } catch (err) {
          console.error("Failed to load reminder", err);
          setError("Failed to load reminder.");
        }
      })();
    }
  }, [id, isEdit]);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    try {
      if (isEdit) {
        await updateReminder(id, form);
        alert("Reminder updated successfully!");
      } else {
        await createReminder(form);
        alert("Reminder created successfully!");
      }
      navigate("/dashboard");
    } catch (err) {
      console.error(err);
      setError(err.response?.data?.detail || "Something went wrong");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <form onSubmit={handleSubmit} className="bg-white p-6 rounded shadow-md w-full max-w-lg">
        <h2 className="text-2xl font-bold mb-4 text-blue-600">
          {isEdit ? "Edit Reminder" : "New Reminder"}
        </h2>

        {error && <p className="text-red-500 mb-4">{error}</p>}

        <input
          type="text"
          name="title"
          value={form.title}
          onChange={handleChange}
          placeholder="Title"
          className="w-full p-2 border rounded mb-4"
          required
        />

        <textarea
          name="description"
          value={form.description}
          onChange={handleChange}
          placeholder="Description"
          className="w-full p-2 border rounded mb-4"
        />

        <input
          type="datetime-local"
          name="remind_at"
          value={form.remind_at}
          onChange={handleChange}
          className="w-full p-2 border rounded mb-4"
          required
        />

        <button
          type="submit"
          className="w-full bg-blue-600 text-white p-2 rounded hover:bg-blue-700 transition"
        >
          {isEdit ? "Update Reminder" : "Create Reminder"}
        </button>
      </form>
    </div>
  );
};

export default ReminderForm;
