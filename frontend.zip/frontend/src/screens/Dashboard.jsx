import React, { useEffect, useState } from "react";
import { getReminders, createReminder, updateReminder, deleteReminder } from "../services/api";
import ReminderCard from "../components/ReminderCard";
import ReminderForm from "../components/ReminderForm";
import { useNavigate } from "react-router-dom";

const Dashboard = () => {
  const navigate = useNavigate();
  const [reminders, setReminders] = useState([]);
  const [editingReminder, setEditingReminder] = useState(null);

  const fetchReminders = async () => {
    try {
      const data = await getReminders();
      setReminders(data);
    } catch (error) {
      console.error("Error fetching reminders", error);
      if (error.response?.status === 401) {
        navigate("/login");
      }
    }
  };

  useEffect(() => {
    fetchReminders();
  }, []);

  const handleAddReminder = async (reminder) => {
    await createReminder(reminder);
    fetchReminders();
  };

  const handleEditReminder = (reminder) => {
    setEditingReminder(reminder);
  };

  const handleUpdateReminder = async (reminder) => {
    await updateReminder(reminder);
    setEditingReminder(null);
    fetchReminders();
  };

  const handleDeleteReminder = async (id) => {
    await deleteReminder(id);
    fetchReminders();
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/login");
  };

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-indigo-700">Your Reminders</h1>
        <button
          onClick={handleLogout}
          className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded"
        >
          Logout
        </button>
      </div>

      <ReminderForm
        onSubmit={editingReminder ? handleUpdateReminder : handleAddReminder}
        existingReminder={editingReminder}
        clearForm={() => setEditingReminder(null)}
      />

      <div className="mt-6">
        {reminders.length === 0 ? (
          <p className="text-gray-500">No reminders yet. Add one above!</p>
        ) : (
          reminders.map((reminder) => (
            <ReminderCard
              key={reminder.id}
              reminder={reminder}
              onEdit={handleEditReminder}
              onDelete={handleDeleteReminder}
            />
          ))
        )}
      </div>
    </div>
  );
};

export default Dashboard;
