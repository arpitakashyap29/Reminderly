import React from "react";
import { Routes, Route, Navigate } from 'react-router-dom';
import Login from './components/Login';
import Register from './components/Register';
import Header from './components/Header';
import Protected from './components/Protected';
import ReminderForm from './components/ReminderForm';
import Dashboard from './components/Dashboard';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <Routes>
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route
          path="/dashboard"
          element={
            <Protected>
              <Dashboard />
            </Protected>
          }
        />
        <Route
          path="/reminders/new"
          element={
            <Protected>
              <ReminderForm />
            </Protected>
          }
        />
        <Route
          path="/reminders/:id/edit"
          element={
            <Protected>
              <ReminderForm />
            </Protected>
          }
        />
      </Routes>
    </div>
  );
}

export default App;
